import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { CaseStudies } from "@/components/case-studies"
import { Stats } from "@/components/stats"
import { WorkGallery } from "@/components/work-gallery"
import { Process } from "@/components/process"
import { FAQ } from "@/components/faq"
import { Footer } from "@/components/footer"
import { BackgroundEffects } from "@/components/background-effects"

export default function Home() {
  return (
    <div className="relative min-h-screen overflow-x-hidden selection:bg-cyan-500 selection:text-white">
      <BackgroundEffects />
      <div className="relative z-10 mx-auto flex min-h-screen max-w-[90rem] flex-col">
        <Header />
        <Hero />
        <CaseStudies />
        <Stats />
        <WorkGallery />
        <Process />
        <FAQ />
        <Footer />
      </div>
    </div>
  )
}
