const stats = [
  { value: "80M+", label: "Views Generated" },
  { value: "$35,000", label: "In Client Sales" },
]

export function Stats() {
  return (
    <div className="relative z-10 border-b border-white/5 bg-background/50 py-24 backdrop-blur-sm">
      <div className="mx-auto max-w-[90rem] px-6 md:px-12">
        <div className="mx-auto grid max-w-4xl grid-cols-1 gap-6 md:grid-cols-2">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="group relative flex flex-col items-center justify-center gap-2 rounded-2xl border border-cyan-500/10 bg-[#050518] p-10 shadow-2xl shadow-cyan-900/10 transition-all duration-300 hover:border-cyan-500/20"
            >
              {/* Glow effect */}
              <div className="absolute inset-0 rounded-full bg-cyan-500/5 opacity-0 blur-2xl transition-opacity group-hover:opacity-100" />

              <span className="font-heading relative text-4xl font-bold tracking-tighter text-foreground md:text-5xl">
                {stat.value}
              </span>
              <span className="relative text-xs font-medium uppercase tracking-wide text-cyan-400">{stat.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
