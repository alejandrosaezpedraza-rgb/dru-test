export function BackgroundEffects() {
  return (
    <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      {/* Deep Space Gradient - Cyan Tint */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(6,182,212,0.1),rgba(3,7,18,0)_50%)]" />

      {/* Moving Grid Lines */}
      <div
        className="animate-grid absolute inset-0 z-0 opacity-10"
        style={{
          backgroundImage:
            "linear-gradient(rgba(34,211,238,0.2) 1px, transparent 1px), linear-gradient(90deg, rgba(34,211,238,0.2) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />

      {/* Cyan Light Beams */}
      <div className="beam-container">
        <div className="light-beam left-[10%]" style={{ animationDelay: "0s" }} />
        <div className="light-beam left-[25%]" style={{ animationDelay: "2s", height: "40vh" }} />
        <div className="light-beam left-[40%]" style={{ animationDelay: "4.5s" }} />
        <div className="light-beam left-[60%]" style={{ animationDelay: "1.2s", height: "50vh" }} />
        <div className="light-beam left-[75%]" style={{ animationDelay: "3.8s" }} />
        <div className="light-beam left-[90%]" style={{ animationDelay: "5.5s", height: "35vh" }} />
      </div>

      {/* Stars Overlay */}
      <div className="bg-stars absolute inset-0 opacity-30" />

      {/* Animated Gradient Blobs - Cyan/Blue Tones */}
      <div className="animate-blob absolute left-[10%] top-[-10%] h-[600px] w-[600px] rounded-full bg-cyan-600/10 blur-[100px] mix-blend-screen" />
      <div
        className="animate-blob absolute right-[10%] top-[-10%] h-[600px] w-[600px] rounded-full bg-blue-600/10 blur-[100px] mix-blend-screen"
        style={{ animationDelay: "2s" }}
      />

      {/* Vignette */}
      <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-background/80" />

      {/* Noise Texture */}
      <div
        className="absolute inset-0 z-[1] opacity-[0.04] mix-blend-overlay"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
        }}
      />
    </div>
  )
}
