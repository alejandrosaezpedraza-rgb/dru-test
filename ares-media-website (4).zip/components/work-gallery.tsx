import Image from "next/image"
import { Play } from "lucide-react"

const shortFormVideos = [
  {
    image:
      "https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/32dc342a-6ade-4b51-8b6a-b11d47ef73e8_1600w.png",
    link: "https://www.tiktok.com/@dvcesclipzz/video/7540077845960264982",
    alt: "Short Form 1",
  },
  {
    image:
      "https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/1948e914-00f3-48a7-8ebb-6e841101c6f1_800w.png",
    link: "https://www.tiktok.com/@dvcesclipzz/video/7582160439329492246",
    alt: "Short Form 2",
    overlay: true,
  },
  {
    image:
      "https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/58c339f0-2131-480e-9d73-c2ce351265b1_1600w.png",
    link: "https://www.tiktok.com/@dvces1/video/7546553750962326798",
    alt: "Tech Showcase",
  },
]

const longFormVideos = [
  {
    image: "https://img.youtube.com/vi/5dYZ5aEN5XI/maxresdefault.jpg",
    link: "https://youtu.be/5dYZ5aEN5XI",
    alt: "Long Form 1",
  },
  {
    image: "https://img.youtube.com/vi/ZEtUDwXhnMo/maxresdefault.jpg",
    link: "https://youtu.be/ZEtUDwXhnMo",
    alt: "Video Editor Guide",
  },
]

export function WorkGallery() {
  return (
    <div className="relative z-10 border-b border-white/5 bg-background/50 py-24 backdrop-blur-sm">
      <div className="mx-auto max-w-[90rem] px-6 md:px-12">
        <div className="mb-16 text-center">
          <h2 className="font-heading mb-4 text-4xl font-semibold tracking-tighter text-foreground md:text-5xl">
            Our Work
          </h2>
          <p className="mx-auto max-w-xl text-lg text-slate-400">High-impact assets engineered for viral growth.</p>
        </div>

        {/* Top Row: 3 Short Form (Vertical) */}
        <div className="mb-6 grid grid-cols-1 gap-6 md:grid-cols-3">
          {shortFormVideos.map((video) => (
            <a
              key={video.alt}
              href={video.link}
              target="_blank"
              rel="noopener noreferrer"
              className="group relative aspect-[9/16] overflow-hidden rounded-2xl border border-white/10 bg-[#05050A] transition-all duration-500 hover:border-cyan-500/30"
            >
              <Image
                src={video.image || "/placeholder.svg"}
                alt={video.alt}
                fill
                className="object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-80" />

              {video.overlay && (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40">
                  <h3 className="font-heading -rotate-12 text-4xl font-bold text-cyan-400 mix-blend-overlay">VIRAL?</h3>
                </div>
              )}

              <div className="absolute inset-0 z-10 flex items-center justify-center bg-black/20 transition-opacity duration-300">
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-white shadow-lg shadow-white/20 transition-transform duration-300">
                  <Play className="ml-1 h-5 w-5 fill-black text-black" />
                </div>
              </div>
            </a>
          ))}
        </div>

        {/* Bottom Row: 2 Long Form (Horizontal) */}
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          {longFormVideos.map((video) => (
            <a
              key={video.alt}
              href={video.link}
              target="_blank"
              rel="noopener noreferrer"
              className="group relative aspect-video overflow-hidden rounded-2xl border border-white/10 bg-[#05050A] transition-all duration-500 hover:border-cyan-500/30"
            >
              <Image
                src={video.image || "/placeholder.svg"}
                alt={video.alt}
                fill
                className="object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/30 transition-colors group-hover:bg-black/50" />

              <div className="absolute inset-0 z-10 flex items-center justify-center transition-opacity duration-300">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-white shadow-lg shadow-white/20 transition-transform">
                  <Play className="ml-1 h-6 w-6 fill-black text-black" />
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </div>
  )
}
