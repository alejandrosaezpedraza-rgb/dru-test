import Image from "next/image"
import { Calendar, Eye, ShieldCheck } from "lucide-react"

export function Hero() {
  return (
    <main className="relative flex flex-grow flex-col items-center px-4 pb-20 pt-32 text-center">
      {/* Floating Elements */}
      <div className="animate-float absolute left-10 top-20 hidden opacity-50 lg:left-32 lg:block">
        <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 p-3 backdrop-blur-md">
          <div className="h-2 w-2 animate-pulse rounded-full bg-cyan-400 shadow-[0_0_10px_#22d3ee]" />
          <span className="font-mono text-xs text-slate-300">Revenue: $35,000</span>
        </div>
      </div>
      <div
        className="animate-float absolute bottom-20 right-10 hidden opacity-50 lg:right-32 lg:block"
        style={{ animationDelay: "2s" }}
      >
        <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 p-3 backdrop-blur-md">
          <Eye className="h-4 w-4 text-cyan-400" />
          <span className="font-mono text-xs text-slate-300">80M Views</span>
        </div>
      </div>

      {/* Social Proof Pill */}
      <div className="mb-8 inline-flex cursor-default items-center gap-3 rounded-full border border-white/10 bg-white/[0.03] py-1.5 pl-2 pr-4 shadow-lg shadow-cyan-900/10 ring-1 ring-inset ring-white/5 backdrop-blur-sm transition-colors hover:border-cyan-500/50">
        <div className="flex -space-x-2">
          <Image
            src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/5d8d87f1-9eba-472f-a93c-fb0ee1c02924_320w.jpg"
            className="h-6 w-6 rounded-full border border-background object-cover ring-1 ring-white/20"
            alt="User"
            width={24}
            height={24}
          />
          <Image
            src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/ed025ffa-48eb-4776-8998-3985b598b5ff_320w.jpg"
            className="h-6 w-6 rounded-full border border-background object-cover ring-1 ring-white/20"
            alt="User"
            width={24}
            height={24}
          />
          <Image
            src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/0564cdd8-a5db-4298-9c86-8112bd0d1461_320w.jpg"
            className="h-6 w-6 rounded-full border border-background object-cover ring-1 ring-white/20"
            alt="User"
            width={24}
            height={24}
          />
        </div>
        <span className="text-xs font-medium tracking-wide text-slate-400">
          Trusted by <span className="font-semibold text-foreground">20+ founders</span>
        </span>
      </div>

      {/* Headline */}
      <h1 className="font-heading mb-8 max-w-5xl text-balance text-5xl font-bold leading-[0.95] tracking-tighter text-foreground drop-shadow-2xl md:text-8xl">
        Creating content that <br className="hidden md:block" />
        <span className="bg-gradient-to-r from-white via-cyan-100 to-cyan-800 bg-clip-text text-transparent">
          prints cash.
        </span>
      </h1>

      {/* Subtext */}
      <p className="mx-auto mb-10 max-w-2xl text-pretty text-lg font-normal leading-relaxed text-slate-400 md:text-xl">
        You hit record. We handle the rest — ideas, scripting, editing, posting, and short-form that actually grows your
        audience.
      </p>

      {/* CTA Button */}
      <div className="flex flex-col items-center gap-6">
        <div className="flex gap-4">
          <a
            href="https://calendly.com/alejandrosaezpedraza/ares-media-intro-call"
            target="_blank"
            rel="noopener noreferrer"
            className="group relative inline-flex items-center justify-center overflow-hidden rounded-full bg-white px-10 py-3.5 text-lg font-bold tracking-tight text-black transition-all hover:scale-105 hover:shadow-[0_0_40px_-10px_rgba(34,211,238,0.5)]"
          >
            <span className="absolute h-0 w-0 rounded-full bg-cyan-200 opacity-50 transition-all duration-500 ease-out group-hover:h-56 group-hover:w-56" />
            <Calendar className="mr-2 h-5 w-5 text-black" />
            <span className="relative z-10">Book a call</span>
          </a>
        </div>
        <p className="flex items-center gap-1.5 text-xs font-medium text-slate-500">
          <ShieldCheck className="h-4 w-4 text-cyan-400" />
          Guaranteed results or we work for free.
        </p>
      </div>
    </main>
  )
}
