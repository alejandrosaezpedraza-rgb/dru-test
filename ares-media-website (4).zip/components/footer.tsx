import Image from "next/image"

export function Footer() {
  return (
    <footer className="relative z-10 mt-auto border-t border-white/5 bg-background py-12">
      <div className="mx-auto max-w-[90rem] px-6 md:px-12">
        <div className="flex flex-col items-center justify-between gap-6 md:flex-row">
          {/* Left: Logo + Name */}
          <div className="flex items-center gap-3">
            <div className="relative flex h-8 w-8 items-center justify-center">
              <div className="absolute inset-0 bg-cyan-500 opacity-40 blur-lg" />
              <Image
                src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/aa533da5-fe40-4b8a-9d45-af1bdcadbb0b_320w.png"
                alt="Ares Media Logo"
                width={32}
                height={32}
                className="relative z-10 object-cover drop-shadow-[0_0_10px_rgba(34,211,238,0.8)]"
              />
            </div>
            <span className="font-heading text-lg font-bold tracking-tight text-foreground">Ares Media</span>
          </div>

          {/* Right: X Logo */}
          <a
            href="https://x.com/Aresmedia_"
            target="_blank"
            rel="noopener noreferrer"
            className="text-slate-400 transition-colors hover:text-foreground"
          >
            <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
              <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
            </svg>
          </a>
        </div>

        {/* Copyright Bottom */}
        <div className="mt-8 flex flex-col items-center justify-center gap-4 border-t border-white/5 pt-8 text-xs font-medium text-slate-500 md:flex-row">
          <p>© 2025 Ares Media. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
