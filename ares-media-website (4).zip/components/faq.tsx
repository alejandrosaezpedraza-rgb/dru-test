import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const faqs = [
  {
    question: "Can I get clips only without long-form?",
    answer:
      "Yes. If you already have footage, streams, or long-form videos, we can strictly handle clipping, captioning, and distribution of short-form content.",
  },
  {
    question: "How much do I need to be involved?",
    answer:
      "Very little. You record or stream a couple hours per month — we handle ideas, scripting, editing, posting, and repurposing. You just hit record (or go live).",
  },
  {
    question: "How does your clipping system work?",
    answer:
      "We turn your long-form videos and streams into short-form clips. Clips get posted on your main accounts plus up to three fresh TikTok, YouTube, and Instagram accounts that we create and manage, giving you more reach, testing, and virality potential.",
  },
  {
    question: "Who owns the content you create?",
    answer:
      "You own 100% of everything we produce — videos, edits, and files. We simply operate your content system for you.",
  },
]

export function FAQ() {
  return (
    <div className="relative z-10 border-t border-white/5 bg-background/50 py-24 backdrop-blur-sm">
      <div className="relative z-10 mx-auto max-w-3xl px-6 md:px-12">
        {/* Section Header */}
        <div className="mb-16 text-center">
          <h2 className="font-heading mb-4 text-4xl font-semibold tracking-tighter text-foreground md:text-5xl">
            We have all the answers
          </h2>
          <p className="text-lg text-slate-400">Everything you need to know about the process.</p>
        </div>

        {/* FAQ Accordion */}
        <Accordion type="single" collapsible className="flex flex-col gap-4">
          {faqs.map((faq, index) => (
            <AccordionItem
              key={index}
              value={`item-${index}`}
              className="group overflow-hidden rounded-2xl border border-white/10 bg-[#050518] transition-all duration-300 hover:border-cyan-500/30"
            >
              <AccordionTrigger className="font-heading flex w-full cursor-pointer select-none items-center justify-between p-6 text-left text-lg font-medium text-foreground [&[data-state=open]>div]:rotate-45 [&>svg]:hidden">
                {faq.question}
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-white/10 bg-white/5 transition-transform duration-300">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M5 12h14" />
                    <path d="M12 5v14" />
                  </svg>
                </div>
              </AccordionTrigger>
              <AccordionContent className="px-6 pb-6 leading-relaxed text-slate-400">{faq.answer}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </div>
  )
}
