import Image from "next/image"
import { Eye, Wallet } from "lucide-react"

const caseStudies = [
  {
    name: "Leens",
    category: "Crypto",
    image:
      "https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/cdeffcd4-218d-428e-9135-90340ae8595e_800w.jpg",
    views: "2M",
    cash: null,
  },
  {
    name: "DVCES",
    category: "Crypto",
    image:
      "https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/f8f7c5eb-1662-49ab-ae5b-33655fa68374_800w.jpg",
    views: "5M",
    cash: "$25,000",
  },
  {
    name: "Connoreo",
    category: "Crypto",
    image:
      "https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/bc9347b7-d90a-4ecc-b145-58f8b056fb1c_800w.jpg",
    views: "1M",
    cash: "$10,000",
  },
  {
    name: "Jack Duval",
    category: "Crypto",
    image:
      "https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/664c465a-dee1-4bb0-8e1d-a2a995f821fe_800w.jpg",
    views: "500K",
    cash: null,
  },
]

export function CaseStudies() {
  return (
    <div
      id="case-studies"
      className="relative w-full overflow-hidden border-y border-white/5 bg-background/50 py-24 backdrop-blur-sm"
    >
      {/* Background glow */}
      <div className="pointer-events-none absolute left-1/2 top-0 h-[500px] w-[1000px] -translate-x-1/2 rounded-full bg-cyan-600/5 blur-[120px]" />

      <div className="relative z-10 mx-auto max-w-[90rem] px-6 md:px-12">
        {/* Section Header */}
        <div className="mb-16 flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div>
            <span className="mb-3 block text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">Portfolio</span>
            <h2 className="font-heading mb-4 text-4xl font-semibold tracking-tighter text-foreground md:text-5xl">
              Case Studies
            </h2>
            <p className="max-w-xl text-lg text-slate-400">
              Recent campaigns where we broke the algorithm and generated massive ROI.
            </p>
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
          {caseStudies.map((study) => (
            <div
              key={study.name}
              className="card-gradient group relative flex aspect-[4/5] flex-col overflow-hidden rounded-3xl border border-white/10 bg-[#05050A]"
            >
              {/* Image */}
              <div className="absolute inset-0">
                <Image
                  src={study.image || "/placeholder.svg"}
                  alt={study.name}
                  fill
                  className="object-cover opacity-70 transition-transform duration-700 group-hover:scale-110 group-hover:opacity-50"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
              </div>

              {/* Content */}
              <div className="absolute bottom-0 left-0 z-20 w-full p-6">
                <div className="mb-5">
                  <span className="mb-2 block text-[10px] font-bold uppercase tracking-widest text-cyan-400">
                    {study.category}
                  </span>
                  <h3 className="font-heading text-2xl font-medium tracking-tight text-foreground">{study.name}</h3>
                </div>

                <div className="grid grid-cols-2 gap-4 border-t border-white/10 pt-4">
                  <div>
                    <div className="mb-1 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      <Eye className="h-3 w-3 text-foreground" /> Views
                    </div>
                    <div className="text-xl font-bold tracking-tight text-foreground">{study.views}</div>
                  </div>
                  <div>
                    <div className="mb-1 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      <Wallet className={`h-3 w-3 ${study.cash ? "text-emerald-400" : "text-slate-500"}`} /> Cash
                    </div>
                    <div
                      className={`text-xl font-bold tracking-tight ${study.cash ? "text-emerald-400" : "text-slate-500"}`}
                    >
                      {study.cash || "N/A"}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
