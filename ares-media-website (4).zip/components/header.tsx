import Link from "next/link"
import Image from "next/image"
import { Calendar } from "lucide-react"

export function Header() {
  return (
    <header className="sticky top-0 z-50 flex items-center justify-between border-b border-white/5 bg-background/50 px-6 py-6 backdrop-blur-xl md:px-12">
      <div className="flex items-center gap-3 text-foreground">
        <div className="relative flex h-10 w-10 items-center justify-center">
          <div className="absolute inset-0 bg-cyan-500 opacity-40 blur-lg" />
          <Image
            src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/aa533da5-fe40-4b8a-9d45-af1bdcadbb0b_320w.png"
            alt="Ares Media Logo"
            width={40}
            height={40}
            className="relative z-10 object-cover drop-shadow-[0_0_10px_rgba(34,211,238,0.8)]"
          />
        </div>
        <span className="font-heading text-xl font-bold tracking-tight">Ares Media</span>
      </div>
      <div className="hidden items-center gap-6 md:flex">
        <nav className="flex gap-6 text-sm font-medium text-slate-400">
          <Link href="#process" className="transition-colors hover:text-cyan-400">
            Process
          </Link>
          <Link href="#case-studies" className="transition-colors hover:text-cyan-400">
            Case Studies
          </Link>
        </nav>
        <div className="h-4 w-px bg-white/10" />
        <a
          href="https://calendly.com/alejandrosaezpedraza/ares-media-intro-call"
          target="_blank"
          rel="noopener noreferrer"
          className="group flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs font-semibold text-slate-300 transition-colors hover:bg-white/10"
        >
          <Calendar className="h-3.5 w-3.5 transition-colors group-hover:text-cyan-400" />
          Book Call
        </a>
      </div>
    </header>
  )
}
