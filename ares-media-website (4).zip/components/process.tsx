import { Compass, PenLine, Video, Scissors } from "lucide-react"

const steps = [
  {
    icon: Compass,
    title: "Strategy",
    description:
      "Deep dive into your brand and audience to engineer a content system built for growth and monetization.",
  },
  {
    icon: PenLine,
    title: "Scripting",
    description: "We write retention-focused scripts and outlines so you always know exactly what to say on camera.",
  },
  {
    icon: Video,
    title: "Production & Posting",
    description:
      "You record. We do the rest — editing, titles, descriptions, thumbnails, upload optimization, and scheduling.",
  },
  {
    icon: Scissors,
    title: "Clipping & Distribution",
    description:
      "Your long-form becomes endless short-form. We cut, caption, and distribute clips to maximize reach and revenue.",
  },
]

export function Process() {
  return (
    <div id="process" className="relative z-10 border-b border-white/5 bg-background/50 py-24 backdrop-blur-sm">
      {/* Background Blob */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-[600px] w-[800px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-cyan-500/5 blur-[120px]" />

      <div className="relative z-10 mx-auto max-w-[90rem] px-6 md:px-12">
        <div className="mb-20 text-center">
          <h2 className="font-heading text-4xl font-semibold tracking-tighter text-foreground md:text-5xl">
            How do we do this?
          </h2>
        </div>

        {/* Process Grid */}
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
          {steps.map((step) => (
            <div
              key={step.title}
              className="group relative flex h-full flex-col items-start rounded-3xl border border-white/10 bg-[#050510] p-8 transition-all duration-300 hover:border-cyan-500/30"
            >
              <div className="mb-6 flex h-12 w-12 items-center justify-center rounded-lg border border-cyan-500/20 bg-cyan-500/10 text-cyan-400 transition-transform duration-500 group-hover:scale-110">
                <step.icon className="h-6 w-6" strokeWidth={1.5} />
              </div>
              <h3 className="font-heading mb-3 text-xl font-semibold tracking-tight text-foreground">{step.title}</h3>
              <p className="text-base font-normal leading-relaxed text-slate-400">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
